import type { Config } from 'tailwindcss'

export default {
  darkMode: 'class',
  content: [
    './index.html',
    './src/**/*.{ts,tsx}',
    './.storybook/**/*.{ts,tsx}'
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          50: '#f5f8ff', 100: '#e6edff', 200: '#c7d4ff', 300: '#a7bbff', 400: '#6f8fff',
          500: '#4c6bff', 600: '#3b54db', 700: '#2f43b1', 800: '#253689', 900: '#1e2b6b'
        }
      }
    }
  },
  plugins: []
} satisfies Config
